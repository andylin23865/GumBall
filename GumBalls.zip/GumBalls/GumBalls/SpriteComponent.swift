//
//  SpriteComponent.swift
//  GumBalls
//
//  Created by apple on 2019/12/3.
//  Copyright © 2019 andy. All rights reserved.
//

import SpriteKit
import GameplayKit

class ​SpriteComponent: GKComponent {
    var node:floor
    init(floorType:FloorType) {
        node = floor(floorType: floorType,funType: FunType(effect: .nothing, coeff: 0, fixedNum: 0))
        super.init()
    }
    
    required init?(coder: NSCoder) {
        fatalError("...")
    }
}
