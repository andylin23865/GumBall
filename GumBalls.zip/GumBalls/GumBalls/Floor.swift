//
//  Floor.swift
//  GumBalls
//
//  Created by apple on 2019/12/2.
//  Copyright © 2019 andy. All rights reserved.
//

import SpriteKit
import GameplayKit

enum FloorType:Int{
    case isMonster
    
    case isLifeBottle
    
    case isAttackBottle
    
    case isExplore
    
    case isGood
    
    case isNothing
}

enum NodeLevel:CGFloat{
    case sta = 1.0
    case back = 5.0
    case front = 10.0
    case moving = 100.0
    case doing = 1000.0
}

enum EffectType{
    case nothing
    case life
    case magic
    case physicAttack
    case magicAttack
    case physicDamage
    case magicDamage
}

class FunType {
    var effect:EffectType
    var coeff:Double
    var fixedNum:Double
    
    init(effect:EffectType,coeff:Double,fixedNum:Double) {
        self.effect = effect
        self.coeff = coeff
        self.fixedNum = fixedNum
    }
    
    func calculateTheResult(num:Double)->Int{
        return (Int)(coeff*num + fixedNum)
    }
}

class Monster {
    var life:Int
    var attack:Int
    var index:Int!
    init(life:Int,attack:Int) {
        self.life = life
        self.attack = attack
    }
}

class floor:SKSpriteNode{
    
    var floorType:FloorType
    var frontTexture:SKTexture
    var backTexture:SKTexture
    var funType:FunType
    var coverUp = true
    
    var monster:Monster
    
    var life = SKSpriteNode()
    var lifeNum = SKLabelNode()
    var attack = SKSpriteNode()
    var attackNum = SKLabelNode()
    
    func calculateGoodResult()->Int{
        if self.floorType == .isGood{
            switch funType.effect {
            case .life:
                return funType.calculateTheResult(num: (Double)(gumBall.life))
            case .magic:
                return funType.calculateTheResult(num: (Double)(gumBall.magic))
            case .magicAttack:
                return funType.calculateTheResult(num: (Double)(gumBall.magicAttack))
            case .physicAttack:
                return funType.calculateTheResult(num: (Double)(gumBall.physicAttack))
            case .magicDamage:
                return funType.calculateTheResult(num: (Double)(gumBall.magicAttack))
            case .physicDamage:
                return funType.calculateTheResult(num: (Double)(gumBall.physicAttack))
            default:
                return -1
            }
        }else
        {
            return -1
        }
    }
    
    func setLabel(text:String,position:CGPoint)->SKLabelNode{
        let label = SKLabelNode()
        label.fontName = "OpenSans-Bold"
        label.name = "damageLabel"
        label.fontSize = 12
        label.fontColor = SKColor.black
        label.text = text
        label.position = position
        label.zPosition = NodeLevel.front.rawValue
        return label
    }
    
    func setLabelBack(size:CGSize,position:CGPoint,image:String)->SKSpriteNode{
        let back = SKSpriteNode()
        back.texture = SKTexture(imageNamed: image)
        back.size = size
        back.position = position
        back.zPosition = NodeLevel.back.rawValue
        return back
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("error")
    }
    
    init(floorType:FloorType,funType:FunType) {
        self.funType = funType
        self.floorType = floorType
        self.frontTexture = SKTexture(imageNamed: "floorCover")
        
        switch floorType{
        case .isMonster:
            self.backTexture = SKTexture(imageNamed: "monster1")
            monster = Monster(life: 7, attack: 1)
        case .isLifeBottle:
            self.backTexture = SKTexture(imageNamed: "lifeBottle")
            monster = Monster(life: -1, attack: -1)
        case .isAttackBottle:
                self.backTexture = SKTexture(imageNamed: "attackBottle")
                monster = Monster(life: -1, attack: -1)
        case .isExplore:
                self.backTexture = SKTexture(imageNamed: "explore")
                monster = Monster(life: -1, attack: -1)
        case .isNothing:
            self.backTexture = SKTexture(imageNamed: "nothing")
            monster = Monster(life: -1, attack: -1)
        case .isGood:
            monster = Monster(life: -1, attack: -1)
            switch funType.effect {
                case .life:
                    self.backTexture = SKTexture(imageNamed: "lifeGood")
                case .magic:
                    self.backTexture = SKTexture(imageNamed: "nothing")
                case .magicAttack:
                    self.backTexture = SKTexture(imageNamed: "nothing")
                case .physicAttack:
                    self.backTexture = SKTexture(imageNamed: "nothing")
                case .magicDamage:
                    self.backTexture = SKTexture(imageNamed: "nothing")
                case .physicDamage:
                    self.backTexture = SKTexture(imageNamed: "physicDamageGood")
                default:
                    self.backTexture = SKTexture(imageNamed: "nothing")
            }
        default:
            self.backTexture = SKTexture(imageNamed: "nothing")
            monster = Monster(life: -1, attack: -1)
        }
        
        super.init(texture: frontTexture, color: .clear, size: frontTexture.size())
        
        lifeNum = setLabel(text: (String)(monster.life),position: CGPoint(x: self.position.x-self.size.width*0.4, y: self.position.y-self.size.height*(0.48)))
        attackNum = setLabel(text: (String)(monster.attack),position: CGPoint(x: self.position.x-self.size.width*0.4, y: self.position.y+self.size.height*(0.32)))
        
        life = setLabelBack(size: CGSize(width: self.size.width*0.25, height: self.size.height*0.25), position: CGPoint(x: self.position.x-self.size.width*0.4, y: self.position.y-self.size.height*(0.4)), image: "lifeNum")
        attack = setLabelBack(size: CGSize(width: self.size.width*0.25, height: self.size.height*0.25), position: CGPoint(x: self.position.x-self.size.width*0.4, y: self.position.y+self.size.height*(0.4)), image: "physicAttack")
        
        addChild(lifeNum)
        addChild(attackNum)
        
        addChild(life)
        addChild(attack)
        
        self.life.isHidden = true
        self.lifeNum.isHidden = true
        self.attack.isHidden = true
        self.attackNum.isHidden = true
        
        self.zPosition = NodeLevel.sta.rawValue
    }
    
    func disableTheNum(){
        self.life.isHidden = true
        self.lifeNum.isHidden = true
        self.attack.isHidden = true
        self.attackNum.isHidden = true
    }
    
    func flip(){
        let firstHalfFlip = SKAction.scaleX(to: 0.0, duration: 0.2)
        let secondHalfFlip = SKAction.scaleX(to: 1.0, duration: 0.2)
        
        setScale(1.0)
        
        if coverUp {
          run(firstHalfFlip, completion: {
            self.texture = self.backTexture
            if(self.floorType == .isMonster){
                self.life.isHidden = false
                self.lifeNum.isHidden = false
                self.attack.isHidden = false
                self.attackNum.isHidden = false
            }
            
            self.run(secondHalfFlip)
          })
        }
        coverUp = false
    }
    
    func flipImmediately(){
        if coverUp {
            self.texture = self.backTexture
            if(self.floorType == .isMonster){
                self.life.isHidden = false
                self.lifeNum.isHidden = false
                self.attack.isHidden = false
                self.attackNum.isHidden = false
            }
        }
        coverUp = false
    }
    
}
