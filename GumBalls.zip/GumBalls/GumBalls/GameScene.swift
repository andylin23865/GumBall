//
//  GameScene.swift
//  GumBalls
//
//  Created by apple on 2019/11/26.
//  Copyright © 2019 andy. All rights reserved.
//

import SpriteKit
import GameplayKit

enum GameStatus{
    case idle
    
    case running
    
    case over
}

class GameScene: SKScene {
    
    func stopAllAction(){
        for node in self.children{
            node.removeAllActions()
        }
        self.removeAllChildren()
    }
    
    func addStartNode(){
        gameStartNode.fontName = "Chalkduster"
        gameStartNode.text = "START NOW"
        gameStartNode.fontSize = 65
        gameStartNode.fontColor = SKColor.green
        gameStartNode.position = CGPoint(x: frame.midX, y: frame.midY)
           
        addChild(gameStartNode)
    }
    
    func shuffle(){
        //游戏的初始化过程
        addStartNode()
        gameStatus = .idle
        
    }
    
    func createTheFloorInterface(){
        for i in 0..<30{
            allFloor[i].position = CGPoint(x: (Double)(self.size.width)*(0.2*(Double)(i%5+1)-0.1), y: (Double)(self.size.height)*((Double)(i/5+1)*0.10+0.18))
            addChild(allFloor[i])
        }
    }
    
    func creatTheLevelInterFace(){
        self.removeChildren(in: [gameStartNode])
        
        gameStartNode.text = "迷宫第\(level)层          探索点：\(gumBall.explore)"
        gameStartNode.fontSize = 20
        gameStartNode.fontColor = SKColor.green
        gameStartNode.position = CGPoint(x: self.size.width*0.5, y: self.size.height*0.9)
        addChild(gameStartNode)
        
        gumBall.position = CGPoint(x: self.size.width*0.5, y: self.size.height*0.1)
        addChild(gumBall)
        
        package.position = CGPoint(x: self.size.width*0.2, y: self.size.height*0.1)
        package.size = CGSize(width: self.size.width*0.18, height: self.size.width*0.18)
        addChild(package)
        
        reel.position = CGPoint(x: self.size.width*0.8, y: self.size.height*0.1)
        reel.size = CGSize(width: self.size.width*0.18, height: self.size.width*0.18)
        addChild(reel)
        
        packageDetail.position = CGPoint(x: self.size.width*0.5, y: self.size.height*0.5)
        packageDetail.size = CGSize(width: self.size.width*0.8, height: self.size.width*0.8)
        addChild(packageDetail)
        packageDetail.isHidden = true
        
        createTheFloorInterface()
    }
    
    func startGame(){
        //游戏的开始过程
        creatTheLevelInterFace()
        gameStatus = .running
    }
    
    func gameOver(){
        //游戏失败
        
        gameStatus = .over
    }
    
    func MoveUpDown(node:SKNode){
        let DoAction1 = SKAction.moveBy(x: 0, y: 2, duration: 0.7)
        let DoAction2 = SKAction.moveBy(x: 0, y: -2, duration: 0.5)
        let action = SKAction.sequence([DoAction1,DoAction2])
        node.run(SKAction.repeatForever(action))
    }
    
    func MoveOut(node:SKNode)
    {
        let DoAction1 = SKAction.moveBy(x: node.position.x, y: node.position.y, duration: 1)
        node.run(DoAction1, completion: {() in
            self.removeChildren(in: [node])
        })
    }
    
    func moveTo(node:SKNode,dest:CGPoint,duration:TimeInterval){
        let action = SKAction.move(to: dest, duration: duration)
        node.run(action, completion: { () in
            self.removeChildren(in: [node])
        })
    }
    
    override func didMove(to view: SKView) {
        self.backgroundColor = SKColor(red: 80.0/255.0, green: 192.0/255.0, blue: 203.0/255.0, alpha: 1.0)
        if gameStatus == .idle{
            shuffle()
        }else{
            creatTheLevelInterFace()
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        switch gameStatus {
        case .idle:
            startGame()
        case .running:
            //GumBallData.life = GumBallData.life-1
            for touch in touches{
                let tmp = touch.location(in: self)
                let floorNum = whichFloor(touch: tmp)
                if(floorNum != -1) {
                    if allFloor[floorNum].zPosition >= operationLevel{
                        if(allFloor[floorNum].coverUp){allFloor[floorNum].flip()}
                        else{
                            switch allFloor[floorNum].floorType {
                            case .isMonster:
                                physicAttack(floorNum: floorNum)
                                updateTheMonster(floorNum: floorNum)
                                updateTheGumBall()
                                if allFloor[floorNum].monster.life <= 0{
                                    allFloor[floorNum].disableTheNum()
                                    removeTheMonster(floorNum: floorNum)
                                }
                            case .isLifeBottle:
                                gumBall.life = gumBall.life + 5
                                updateTheGumBall()
                                removeTheBottle(floorNum: floorNum)
                            case .isAttackBottle:
                                gumBall.physicAttack = gumBall.physicAttack + 1
                                updateTheGumBall()
                                removeTheBottle(floorNum: floorNum)
                            case .isExplore:
                                gumBall.explore = gumBall.explore + 10
                                updateTheGumBall()
                                removeTheBottle(floorNum: floorNum)
                            case .isGood:
                                let tmp = floor(floorType: allFloor[floorNum].floorType, funType: allFloor[floorNum].funType)
                                packageDetail.addGood(good: tmp)
                                removeTheGood(floorNum: floorNum)
                            default:
                                print("nothing")
                            }
                        }
                    }
                }
                if package.contains(touch.location(in: self)){
                    if package.zPosition >= operationLevel{
                        packageDetail.isHidden = false
                        operationLevel = packageDetail.zPosition
                    }
                }else if !packageDetail.contains(touch.location(in: self)) && !packageDetail.isHidden{
                    if packageDetail.zPosition >= operationLevel{
                        packageDetail.hide()
                        operationLevel = 0
                    }
                }
                else if packageDetail.contains(touch.location(in: self)) && !packageDetail.isHidden{
                    if packageDetail.zPosition >= operationLevel{
                        print(packageDetail.whichProp(point: CGPoint(x: touch.location(in: self).x-packageDetail.position.x, y: touch.location(in: self).y-packageDetail.position.y)))
                    }
                }
            }
            //print("runing")
        case .over:
            print("return\n")
        default:
            print("error")
        }
    }
    
    func removeTheMonster(floorNum:Int){
        let tmp = allFloor[floorNum]
        let positionTmp = allFloor[floorNum].position
        MoveOut(node: tmp)
        //self.removeChildren(in: [tmp])
        
        allFloor[floorNum] = floor(floorType: .isNothing,funType: FunType(effect: .nothing, coeff: 0, fixedNum: 0))
        allFloor[floorNum].flipImmediately()
        allFloor[floorNum].position = positionTmp
        addChild(allFloor[floorNum])
    }
    
    func removeTheGood(floorNum:Int){
        let tmp = allFloor[floorNum]
        let positionTmp = allFloor[floorNum].position
        moveTo(node: tmp, dest: package.position, duration: 1)
        //self.removeChildren(in: [tmp])
        
        allFloor[floorNum] = floor(floorType: .isNothing,funType: FunType(effect: .nothing, coeff: 0, fixedNum: 0))
        allFloor[floorNum].flipImmediately()
        allFloor[floorNum].position = positionTmp
        addChild(allFloor[floorNum])
    }

    
    func removeTheBottle(floorNum:Int){
        let tmp = allFloor[floorNum]
        let positionTmp = allFloor[floorNum].position
        moveTo(node: tmp, dest: gumBall.position, duration: 1)
        //self.removeChildren(in: [tmp])
        
        allFloor[floorNum] = floor(floorType: .isNothing,funType: FunType(effect: .nothing, coeff: 0, fixedNum: 0))
        allFloor[floorNum].flipImmediately()
        allFloor[floorNum].position = positionTmp
        addChild(allFloor[floorNum])
    }
    
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
        //updateTheGumBall()
    }
}
