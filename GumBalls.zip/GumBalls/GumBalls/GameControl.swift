//
//  GameControl.swift
//  GumBalls
//
//  Created by apple on 2019/12/2.
//  Copyright © 2019 andy. All rights reserved.
//

import SpriteKit
import GameplayKit

func physicAttack(floorNum:Int){
    if allFloor[floorNum].floorType == FloorType.isMonster{
        allFloor[floorNum].monster.life = allFloor[floorNum].monster.life - gumBall.physicAttack
        gumBall.life = gumBall.life - allFloor[floorNum].monster.attack
    }
}
