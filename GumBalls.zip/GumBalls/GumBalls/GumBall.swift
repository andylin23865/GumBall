//
//  GumBall.swift
//  GumBalls
//
//  Created by apple on 2019/12/2.
//  Copyright © 2019 andy. All rights reserved.
//

import SpriteKit

class GumBall:SKSpriteNode{
    var frontTexture:SKTexture
    
    var lifeNode = SKSpriteNode()
    var magicNode = SKSpriteNode()
    var physicAttackNode = SKSpriteNode()
    var magicAttackNode = SKSpriteNode()
    
    var lifeNumNode = SKLabelNode()
    var magicNumNode = SKLabelNode()
    var physicAttackNumNode = SKLabelNode()
    var magicAttackNumNode = SKLabelNode()
    
    var life:Int
    var magic:Int
    var physicAttack:Int
    var magicAttack:Int
    var explore:Int
    
    func setLabel(text:String,position:CGPoint)->SKLabelNode{
        let label = SKLabelNode()
        label.fontName = "OpenSans-Bold"
        label.name = "damageLabel"
        label.fontSize = 12
        label.fontColor = SKColor.black
        label.text = text
        label.position = position
        label.zPosition = NodeLevel.front.rawValue
        return label
    }
    
    func setLabelBack(size:CGSize,position:CGPoint,image:String)->SKSpriteNode{
        let back = SKSpriteNode()
        back.texture = SKTexture(imageNamed: image)
        back.size = size
        back.position = position
        back.zPosition = NodeLevel.back.rawValue
        return back
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("error")
    }
    
    init(life:Int,magic:Int,physicAttack:Int,magicAttack:Int,explore:Int) {
        self.frontTexture = SKTexture(imageNamed: "player1")
        
        self.life = life
        self.magic = magic
        self.physicAttack = physicAttack
        self.magicAttack = magicAttack
        self.explore = explore
        
        super.init(texture: frontTexture, color: .clear, size: frontTexture.size())
        
        lifeNumNode = setLabel(text: (String)(life),position: CGPoint(x: self.position.x-self.size.width*0.8, y: self.position.y-self.size.height*(0.48)))
        physicAttackNumNode = setLabel(text: (String)(physicAttack),position: CGPoint(x: self.position.x-self.size.width*0.8, y: self.position.y+self.size.height*(0.32)))
        
        magicNumNode = setLabel(text: (String)(magic),position: CGPoint(x: self.position.x+self.size.width*0.8, y: self.position.y-self.size.height*(0.48)))
        magicAttackNumNode = setLabel(text: (String)(magicAttack),position: CGPoint(x: self.position.x+self.size.width*0.8, y: self.position.y+self.size.height*(0.32)))
        
        lifeNode = setLabelBack(size: CGSize(width: self.size.width*0.4, height: self.size.width*0.4), position: CGPoint(x: self.position.x-self.size.width*0.8, y: self.position.y-self.size.height*(0.4)), image: "lifeNum")
        physicAttackNode = setLabelBack(size: CGSize(width: self.size.width*0.4, height: self.size.width*0.4), position: CGPoint(x: self.position.x-self.size.width*0.8, y: self.position.y+self.size.height*(0.4)), image: "physicAttack")
        
        magicNode = setLabelBack(size: CGSize(width: self.size.width*0.4, height: self.size.width*0.4), position: CGPoint(x: self.position.x+self.size.width*0.8, y: self.position.y-self.size.height*(0.4)), image: "magicNum")
        magicAttackNode = setLabelBack(size: CGSize(width: self.size.width*0.4, height: self.size.width*0.4), position: CGPoint(x: self.position.x+self.size.width*0.8, y: self.position.y+self.size.height*(0.4)), image: "magicAttack")
        
        addChild(lifeNumNode)
        addChild(physicAttackNumNode)
        
        addChild(magicNumNode)
        addChild(magicAttackNumNode)
        
        addChild(lifeNode)
        addChild(physicAttackNode)
        
        addChild(magicNode)
        addChild(magicAttackNode)
        
        self.zPosition = NodeLevel.sta.rawValue
    
    }
}
