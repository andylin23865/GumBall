//
//  EntityManager.swift
//  GumBalls
//
//  Created by apple on 2019/12/3.
//  Copyright © 2019 andy. All rights reserved.
//

import Foundation
import SpriteKit
import GameplayKit

class EntityManger {
    var entities = Set<GKEntity>()
    let scene:SKScene
    
    init(scene:SKScene) {
        self.scene = scene
    }
    
    func add(_ entity:GKEntity){
        entities.insert(entity)
        
        if let spriteNode = entity.component(ofType: ​SpriteComponent.self)?.node{
            scene.addChild(spriteNode)
        }
    }
    
    func remove(_ entity:GKEntity){
        if let spriteNode = entity.component(ofType: ​SpriteComponent.self)?.node{
            spriteNode.removeFromParent()
        }
        entities.remove(entity)
        
    }
    
}
