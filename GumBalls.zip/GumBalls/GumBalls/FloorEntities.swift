//
//  FloorEntities.swift
//  GumBalls
//
//  Created by apple on 2019/12/3.
//  Copyright © 2019 andy. All rights reserved.
//

import SpriteKit
import GameplayKit

class FloorEntities:GKEntity{
    init(floorType:FloorType) {
        super.init()
        
        let spriteComponent = ​SpriteComponent(floorType: floorType)
        addComponent(spriteComponent)
    }
    
    required init?(coder: NSCoder) {
        fatalError("...")
    }
}
