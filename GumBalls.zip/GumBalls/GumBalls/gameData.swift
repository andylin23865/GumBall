//
//  gameControl.swift
//  GumBalls
//
//  Created by apple on 2019/11/26.
//  Copyright © 2019 andy. All rights reserved.
//

import SpriteKit
import GameplayKit

/*before the level the data should be exsited*/

var allProp = [FloorType]()
var allFloor = [floor]()
var level:Int = 1
var gumBall = GumBall(life: 50, magic: 30, physicAttack: 3, magicAttack: 1, explore: 20)
var package = Package()
var reel = Reel()
var packageDetail = PackageDetail()
var operationLevel:CGFloat = 0.0

/*the data should be exsited all the way*/

var gameStartNode = SKLabelNode()

/*the data shou be exsited when you play the game*/

var gameStatus = GameStatus.idle
var selectedDamage = 0

/*some function*/

func deleteTheProSet(){
    while !allProp.isEmpty{
        allProp.removeAll()
    }
}

func createThePropSet(){
    for _ in 0..<30{
        allProp.append(.isNothing)
    }
}

func calculateTheProp(allFloorNum:Int,allPropNum:Int,kind:FloorType){
    var num = 0
    while(num < allPropNum){
        let randomNum = Int(arc4random()%(UInt32)(allFloorNum))
        if allProp[randomNum] == .isNothing {
            allProp[randomNum] = kind
            num = num+1
        }
    }
}

func deleteTheFloorSet(){
    while !allFloor.isEmpty{
        allFloor.removeAll()
    }
}

func createTheFloor(){
    for i in 0..<6{
        for j in 0..<5{
            if(allProp[i*5+j] != .isGood){
                allFloor.append(floor(floorType: allProp[i*5+j],funType: FunType(effect: .nothing, coeff: 0, fixedNum: 0)))
            }else{
                switch /*Int(arc4random()%(UInt32)(6))*/5 {
                case 1:
                    allFloor.append(floor(floorType: allProp[i*5+j],funType: FunType(effect: .life, coeff: 0, fixedNum: 10)))
                case 2:
                    allFloor.append(floor(floorType: allProp[i*5+j],funType: FunType(effect: .magic, coeff: 0, fixedNum: 15)))
                case 3:
                    allFloor.append(floor(floorType: allProp[i*5+j],funType: FunType(effect: .physicAttack, coeff: 0, fixedNum: 2)))
                case 4:
                    allFloor.append(floor(floorType: allProp[i*5+j],funType: FunType(effect: .magicAttack, coeff: 0, fixedNum: 2)))
                case 5:
                    allFloor.append(floor(floorType: allProp[i*5+j],funType: FunType(effect: .physicDamage, coeff: 1.2, fixedNum: 3)))
                case 6:
                    allFloor.append(floor(floorType: allProp[i*5+j],funType: FunType(effect: .magicDamage, coeff: 1.6, fixedNum: 5)))
                default:
                   allFloor.append(floor(floorType: allProp[i*5+j],funType: FunType(effect: .nothing, coeff: 0, fixedNum: 0)))
                }
            }
        }
    }
}


func createTheLevelData(){
    deleteTheProSet()
    createThePropSet()
    calculateTheProp(allFloorNum: 30, allPropNum: 5, kind: .isMonster)
    calculateTheProp(allFloorNum: 30, allPropNum: 2, kind: .isLifeBottle)
    calculateTheProp(allFloorNum: 30, allPropNum: 1, kind: .isAttackBottle)
    calculateTheProp(allFloorNum: 30, allPropNum: 3, kind: .isExplore)
    calculateTheProp(allFloorNum: 30, allPropNum: 8, kind: .isGood)
    createTheFloor()
}


func inTheFloor(index:CGPoint,center:CGPoint,size_x:Double,size_y:Double)->Bool{
    return ((Double)(index.x) > (Double)(center.x)-size_x/2 && (Double)(index.x) < (Double)(center.x)+size_x/2) && ((Double)(index.y) > (Double)(center.y)-size_y/2 && (Double)(index.y) < (Double)(center.y)+size_y/2)
}

func whichFloor(touch:CGPoint)->Int{
    for i in 0..<30{
        if(inTheFloor(index: touch, center: allFloor[i].position, size_x: Double(allFloor[i].size.width),size_y: Double(allFloor[i].size.height))){
            return i
        }
    }
    return -1
}

func updateTheMonster(floorNum:Int){
    if allFloor[floorNum].monster.life > 0{
        allFloor[floorNum].attackNum.text = (String)(allFloor[floorNum].monster.attack)
        allFloor[floorNum].lifeNum.text =  (String)(allFloor[floorNum].monster.life)
    }else{
        allFloor[floorNum].attackNum.text = (String)(allFloor[floorNum].monster.attack)
        allFloor[floorNum].lifeNum.text =  (String)(0)
        allFloor[floorNum].monster.life = 0
    }
}

func updateTheGumBall(){
    gumBall.physicAttackNumNode.text = (String)(gumBall.physicAttack)
    gumBall.lifeNumNode.text = (String)(gumBall.life)
    gumBall.magicAttackNumNode.text = (String)(gumBall.magicAttack)
    gumBall.magicNumNode.text = (String)(gumBall.magic)
    updateTheExploreAndLevel()
}

func updateTheExploreAndLevel(){
    gameStartNode.text = "迷宫第\(level)层          探索点：\(gumBall.explore)"
}

func updateTheLevelAndMonsterNum(){
    level = level+1
    updateTheExploreAndLevel()
}
