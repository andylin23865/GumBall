//
//  PackageScene.swift
//  GumBalls
//
//  Created by apple on 2019/12/2.
//  Copyright © 2019 andy. All rights reserved.
//

import SpriteKit
import GameplayKit

class PackageScene: SKScene {
    override func didMove(to view: SKView) {
        self.backgroundColor = SKColor(red: 80.0/255.0, green: 192.0/255.0, blue: 203.0/255.0, alpha: 1.0)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let doors = SKTransition.doorway(withDuration: 0.5)
        let nextPackagesScene = GameScene()
        nextPackagesScene.size = CGSize(width: self.size.width, height: self.size.height)
        nextPackagesScene.scaleMode = .aspectFill
        self.view?.presentScene(nextPackagesScene,transition: doors)
    }
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
        //updateTheGumBall()
    }
}
