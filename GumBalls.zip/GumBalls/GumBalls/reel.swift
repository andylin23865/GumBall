//
//  reel.swift
//  GumBalls
//
//  Created by apple on 2019/12/2.
//  Copyright © 2019 andy. All rights reserved.
//

import SpriteKit

class Reel: SKSpriteNode {
    var frontTexture:SKTexture

    required init?(coder aDecoder: NSCoder) {
        fatalError("error")
    }
    
    init() {
        self.frontTexture = SKTexture(imageNamed: "reel")

        super.init(texture: frontTexture, color: .clear, size: frontTexture.size())
        
        self.zPosition = NodeLevel.sta.rawValue
    
    }
}
