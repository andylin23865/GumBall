//
//  package.swift
//  GumBalls
//
//  Created by apple on 2019/12/2.
//  Copyright © 2019 andy. All rights reserved.
//

import SpriteKit

class Package: SKSpriteNode {
    var frontTexture:SKTexture
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("error")
    }

    init() {
        self.frontTexture = SKTexture(imageNamed: "package")

        super.init(texture: frontTexture, color: .clear, size: frontTexture.size())
        
        self.zPosition = NodeLevel.sta.rawValue
    
    }
}

class PackageDetail: SKSpriteNode {
    var backgroundTexture:SKTexture
    var prop = [floor]()
    var maxProp = 25
    var nowProp = 0
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("error")
    }

    init() {
        
        backgroundTexture = SKTexture()
        
        super.init(texture: backgroundTexture, color: .clear, size: backgroundTexture.size())
        
        self.zPosition = NodeLevel.doing.rawValue
    }
    
    func addGood(good:floor){
        prop.append(good)
            
        addChild(good)
        
        let i = nowProp/5
        let j = nowProp%5
        
        good.position = CGPoint(x: (CGFloat)(j-2)*0.2*self.size.width, y:(CGFloat)(2-i)*0.2*self.size.height)
        good.size = CGSize(width: self.size.width*0.18, height: self.size.height*0.18)
        
        good.zPosition = self.zPosition + 1
        
        good.flipImmediately()
        
        nowProp = nowProp+1
    }
    
    func useProp(num:Int){
        switch prop[num].funType.effect {
        case .life:
            gumBall.life = gumBall.life + prop[num].calculateGoodResult()
        case .magic:
            gumBall.magic = gumBall.magic + prop[num].calculateGoodResult()
        case .magicAttack:
            gumBall.magicAttack = gumBall.magicAttack + prop[num].calculateGoodResult()
        case .physicAttack:
            gumBall.physicAttack = gumBall.physicAttack + prop[num].calculateGoodResult()
        case .magicDamage:
            selectedDamage = prop[num].calculateGoodResult()
        case .physicDamage:
            selectedDamage = prop[num].calculateGoodResult()
        default:
            print("error")
        }
    }
    
    func whichProp(point:CGPoint)->Int{
        for i in 0..<nowProp{
            if prop[i].contains(point){
                return i
            }
        }
        return -1
    }
    
    func hide(){
        self.isHidden = true
    }
}
